#Filename: ZallaM_CS1_S13_Lab10.py
#Author: Michael Zalla (UC Login ID: zallajm)
#CS1 - Spring 2013

#Lab 10 Assignment

###############################################################################
#
# Functional Requirements:
# 
# 1. The game should show a description when the game starts, or when the user
#     types 'help'. This description must let the player know what actions are
#     allowed
# 
# 2. The game must include at least 5 locations (rooms, areas, etc) that the
#     user can navigate between. Upon navigating to a new area, the game must
#     print out a name and description of the location
# 
# 3. The game must allow for at least six actions per location
#     These may include 'north','south','east','west','help' and 'exit'.
#     Some actions/directions may be invalid in certain locations, but you must
#     give the player some kind of feedback, regardless (e.g. - "You can't do
#     that!"). 
#
# 4. In at least one location, the player must be able to access a special
#     direction (e.g. ? 'down', 'up', etc) that allows them to access a new
#     location
#
# 5. In each location, the player must be able to perform at least one action
#     This action should not move the user to another location. This may mean
#     that the user has an 'inventory' to hold items. The game must allow the 
#     user to check their inventory
# 
# 6. The game must include the ability to win or lose the game
#
###############################################################################

import Game

#Create an instance of our Game
game = Game.Game()

