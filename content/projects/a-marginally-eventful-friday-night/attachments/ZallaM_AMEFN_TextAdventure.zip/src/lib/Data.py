# LOOSE COUPLING FOR THE WIN!

#====== ROOM DATA ======#

rooms = { "OUTSIDE": { "UNVISITED_DESC": "The prestige of a fifth-grader seat comes not without cost. For the last hour, you've stubbornly let your "
                                         "stomach be plagued by the carbon monoxide collecting at the back of the bus. The shame of submitting to this "
                                         "aristocratic gas chamber in return for fleeting social distinction has long-since worn off. The sidewalk is "
                                         "still wet when you step off the bus. Drawing another breath, you welcome in the remedial scent of Petrichor, "
                                         "and try to convince yourself that you're beginning to feel better. The sky is getting darker. You should probably "
                                         "get inside soon. There's nothing to do outside anyway.",
                       "VISITED_DESC": "It's starting to rain outside. You should probably go inside to the KITCHEN.",
                       "CONNECTIONS":   ["KITCHEN"],
                       "LOCKED_MSG": "It's already raining. Besides, why go outside when you have a computer?" },
          
          "KITCHEN": { "UNVISITED_DESC": "The front door shuts behind you. Neither of your parents seem to be home. Sitting on the kitchen table is a "
                                         "NOTE from your parents. More importantly, it looks like someone has left a mysterious PACKAGE beside it. "
                                         "You presume it's from your parents.",
                       "VISITED_DESC":   "Still no sign of your parents.",
                       "CONNECTIONS":   ["OUTSIDE", "BASEMENT", "LIVING ROOM", "BEDROOM"],
                       "LOCKED_MSG": "The house door appears to be locked. Luckily, you've got a spare HOUSE KEY inside your INVENTORY (you can check your "
                       "inventory by typing 'INVENTORY', or simply 'I'). You can EXAMINE any item in your inventory by typing EXAMINE [ITEM] "
                       "(e.g. - 'EXAMINE BALL')." },

          "BASEMENT": { "UNVISITED_DESC": "As you open the door to the basement, you power on your trusty 'Adventure Sleuth' FLASHLIGHT. The light serves as "
                                          "your only guide as you descend the wooden stairs. When you arrive at the bottom, you locate the fuse box. Carefully "
                                          "opening the swinging metal cover, you recognize a small BROKEN FUSE. The lightning strike must have overcharged the "
                                          "current to the fuse box, melting the metal strip inside the fuse and rendering your house powerless. You'll need to "
                                          "replace the BROKEN FUSE with a new FUSE in order to restore power.",
                        "VISITED_DESC": "You're back inside the basement, desperately hoping that the BATTERIES will last inside your FLASHLIGHT. The fuse box "
                                        "will need a new FUSE installed in order for the power to come back on.",
                        "CONNECTIONS": ["KITCHEN"],
                        "LOCKED_MSG": "There's nothing to do down there!",
                        "LOCKED_MSG_2": "You open the door that leads down to the BASEMENT. The creaky wooden steps descend into complete darkness, the result of "
                                        "a distinct lack of windows. Even a dim fifth-grader like yourself know not to venture into such depths without proper "
                                        "LIGHT. You shut the door and return to the KITCHEN." },
         
         "LIVING ROOM": { "UNVISITED_DESC": "You enter into the living room. Behind an armchair sits your RC car, a wireless remote-controlled toy. It's somewhat "
                                            "depressing how senseless your old toys now seem after getting a computer. What was once your only desire has now become "
                                            "a vehicle for maturity, the inescapable embrace that slowly suffocate the magic of childhood. You bet the car's still got "
                                            "a BATTERY inside.",
                          "VISITED_DESC": "Visited: You enter into the living room. The RC car still sits behind the armchair.",
                          "CONNECTIONS": ["KITCHEN"],
                          "LOCKED_MSG": "There's nothing to do in there!" },
        
         "BEDROOM": { "UNVISITED_DESC": "Ah, your BEDROOM. The only refuge from your parent's attempts to pry into their fifth-grader's dubious activities and elaborate "
                                        "social life. In your room sits a bed, dresser, bookshelf, and desk. At this desk sits your prized Commodore 64, a technological "
                                        "marvel, clocking in at a rapid 1MHz. You consider yourself fairly lucky to own such a system, but, in all honesty, most kids "
                                        "your age lack the technical expertise to to operate this machine. The desk would be a nice place to open the PACKAGE.",
                      "VISITED_DESC": "You're in your bedroom.",
                      "CONNECTIONS": ["KITCHEN", "BATHROOM"],
                      "LOCKED_MSG": "" },
         
         "BATHROOM": { "UNVISITED_DESC": "You enter into the bathroom. Your father's cordless electric razor is sitting on top of the sink. He'd probably prefer that you "
                                         "keep your prepubescent hands off it. A plastic label on it reads 'x1 AA REQUIRED'. Taking a closer look, you notice that the razor "
                                         "contains a BATTERY!",
                       "VISITED_DESC": "You enter into the bathroom. The razor is still on the sink.",
                       "CONNECTIONS": ["BEDROOM"],
                       "LOCKED_MSG": "There's nothing to do in there!" }

         }

#====== ITEM DATA ======#
         
items = {  "HOUSE KEY":              { "DESC": "A small metal house key. It's a wonder you haven't lost this yet. Maybe you could USE this for something. "
                                               "But enough of the shameless hints ...",
                                       "USE": None },
           
           "NOTE":                   { "DESC": "It's a note, written on a single sheet of your parents' stationery. You've never understood their infatuation with "
                                       "tacky watermarks. Nonetheless, you unfold the note, recognizing the handwriting as that of your mother. The note reads:\n"
                                       "NICK -\n"
                                       "YOUR FATHER AND I HAVE LEFT TONIGHT FOR A FUNDRAISING DINNER. WE WON'T BE HOME UNTIL LATE. THERE'S FOOD "
                                       "IN THE FRIDGE IF YOU GET HUNGRY. WE'VE LEFT YOU SOMETHING SPECIAL, FOR ALL YOUR HARD WORK. HAVE FUN, AND BE SAFE!\n"
                                       "LOVE,\n"
                                       "MOM AND DAD",
                                       "USE": None },
           
           "PACKAGE":                { "DESC": "A small, gift-wrapped box. It's fairly light. An attached tag reads, 'FOR NICK. LOVE, MOM AND DAD.'"
                                       "Looks like your Friday night may not be so dull after all. Not that you've ever placed much trust in your parent's "
                                       "gift ideas. You should probably open it in your BEDROOM.",
                                       "USE": None },
         
           "ADVENTURE SLEUTH GAME":  { "DESC": "It's not just a game. It's 'Adventure Sleuth 2: The Great Lamasery Incident'! You've had this on your birthday "
                                               "list for months! z   You wonder how your parents knew ...",
                                       "USE": None },
         
           "SCISSORS":               { "DESC": "A normal pair of scissors. These might be just what you're looking for.",
                                       "USE" : None },
         
           "BATTERY":                { "DESC": "A standard AA battery. This might come in handy later.",
                                       "USE": None },
         
           "BATTERIES":              { "DESC": "A set of two AA batteries. These could probably power something. You'd have to USE them WITH that something.",
              
                                       "USE": None },
           
           "EMPTY FLASHLIGHT":       { "DESC": "Your trusty 'Adventure Sleuth' flashlight. Man, this thing is cool. It's currently missing its two BATTERIES. "
                                               "Your father probably took them. Does no one in this house respect juvenile property rights?!",
                                       "USE": None },
           
           "FLASHLIGHT":             { "DESC": "Looks like your 'Adventure Sleuth' flashlight is now fully functional! This will come in handy if you "
                                               "need to explore any really dark areas. Hopefully you already knew that!",
                                       "USE": None },
           
           "BROKEN FUSE":            { "DESC": "A broken fuse. Looks like the kind that is easily removable from a fuse box.",
                                       "USE": None },
           
           "FUSE":                   { "DESC": "A brand new electric FUSE. This might be an important piece to the puzzle. Was that breaking the fourth wall, "
                                               "or was it merely innocent description? You can decide for yourself, but it's unlikely that an answer to that "
                                               "question will help with the current predicament.",
                                       "USE": None }
        }

combinations = [ #["PACKAGE", "SCISSORS", "ADVENTURE SLEUTH GAME"],
                 ["BATTERY", "BATTERY", "BATTERIES"],
                 ["BATTERIES", "EMPTY FLASHLIGHT", "FLASHLIGHT"] ]
