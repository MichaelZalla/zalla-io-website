import Data, Item, Utils

class Inventory(object):
  
  def __init__(self, items=None):
    self.inventory = []
    if items != None:
      self.addItems(items)
  
  # Allow Inventory to be iterated over by delegating its iterable to InventoryIterable
  def __iter__(self):
    return InventoryIterable(self)

  def inventory(self):
    return self.inventory

  def addItems(self, items):
    for item in items:
      self.inventory.append(item)
  
  def removeItems(self, itemNames):
    for name in itemNames:
      # Sanitize inputs
      name = name.upper()
      # Try to remove the item from the inventory (duplicates will be safe)
      removed = False
      for index, elem in enumerate(self.inventory):
        # If the name matches, and the item hasn't been removed yet
        if (elem.name == name and removed == False):
          self.inventory.pop(index)
          removed = True
      if(removed == False):
        print name + " not found in inventory."
        print ""
        
  def hasItem(self, itemName):
    name = itemName.upper()
    for item in self:
      if item.name == name:
        return True
    return False

###############################################################################

class InventoryIterable:
 
  def __init__(self, inventory):
    self.inv = inventory
    self.i = -1

  def __iter__(self):
    return self
  
  def next(self):
    if self.i < len(self.inv.inventory) - 1:
      self.i += 1         
      return self.inv.inventory[self.i]
    else:
      raise StopIteration

###############################################################################

class PlayerInventory(Inventory):
  
  def __init__(self, items=None):
    Inventory.__init__(self, items)
  
  # Strange function, but needed for combining sets of two items  
  def hasItems(self, itemName1, itemName2):
  
    name1, name2 = itemName1.upper(), itemName2.upper()
    query = [name1, name2]
    
    hasItemA = False
    hasItemB = False
    # Check that these two (unique) items exist in the inventory
    for itemA in self:
      # If an inventory item matches one in the query list ...
      if itemA.name in query:
        hasItemA = True
        # Remember its inventory index
        i = self.inventory.index(itemA)
        # And remove the item from the query list
        query.remove(itemA.name)
        for itemB in self:
          # This time, skipping the item at index 'i'
          if self.inventory.index(itemB) == i:
            continue
          if itemB.name in query:
            hasItemB = True
          
    # Raise an exception if either item is missing                          
    if(hasItemA == False):
      print "First item does not exist in inventory."
    elif(hasItemB == False):
      print "Second item does not exist in inventory."
    else:
      return True
  
  def combineItems(self, item1, item2):
    # Check that both items exist (uniquely) in the inventory
    if self.hasItems(item1, item2):
      # Check that it's a valid combination
      isValidCombo = False
      for combo in Data.combinations:
        if (combo[0] == item1 and combo[1] == item2) or (combo[0] == item2 and combo[1] == item1):
          # It's a valid combo!
          isValidCombo = True
          
          if combo[2][-1] == 'S':
            print "You combine the " + item1 + " and the " + item2 + " and get some " + combo[2]
          else:
            print "You combine the " + item1 + " and the " + item2 + " and get a " + combo[2]
          
          # Remove the 'consumed' items
          self.removeItems([item1, item2])
          # Add the resulting new item
          item = Item.Item(combo[2])
          Utils.Formatter.output(item.examine())
          self.addItems([item])
          
      if(isValidCombo == False):
        print "Not a valid combination of items."
        
  def display(self):
    if len(self.inventory) > 0:
      output = "Your inventory contains: "
      output += Utils.Formatter.outputList(self.inventory)
      print output
    else:
      print "You inventory is currently empty."
    print ""

###############################################################################

class RoomInventory(Inventory):

  def __init__(self, items=None):
    Inventory.__init__(self, items)
        
  def display(self):
    if len(self.inventory) > 0:
      output = "The room contains: "
      output += Utils.Formatter.outputList(self.inventory)
      print output
    else:
      print "This room contains nothing of interest."
    print ""
