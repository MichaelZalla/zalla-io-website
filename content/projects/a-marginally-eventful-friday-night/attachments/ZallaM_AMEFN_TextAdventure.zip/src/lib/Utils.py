import textwrap

class Formatter(object):

  def __init__(self):
    pass
  
  @staticmethod
  def output(string,width=80):
    lines = []
    splitStr = string.splitlines() #Used to preserve newline printing
    #["This is "] ["a mutli-line "] ["sentence "]
    for line in splitStr:
      for l in textwrap.wrap(line,width):
        lines.append(l)
    lines.append("")
      
    for line in lines:
      print line
    
  @staticmethod      
  def outputList(iterable):
    
    if len(iterable) > 0:
      ret = ""
      for elem in iterable:
        e = ""
        #Singular
        if str(elem)[-1].lower() != "s":     
          e += ("a " + str(elem))
        #Plural
        else:                        
          e += ("some " + str(elem))
        #If it's not the last element in the list
        if iterable.index(elem) != (len(iterable)-1):
          e += ", "
        else:
          if len(iterable) != 1:
            e = "and " + e + "."
          else:
            e += "."
        #Add to the list
        ret += e
      ret = str(ret[0].upper() + ret[1:])
      return ret
    else:
      return "Nothing."