import Data, Inventory, Utils

class Room(object):
  
  name = None
  dataHandle = None
  connections = []
  
  unvisitedDesc = ""
  visitedDesc = ""
  
  visited = False
  locked = False
  
  def __init__(self, name, locked=False):
        
    # Check if it's a valid room
    validRoom = False
    for key in Data.rooms:
      if key == name.upper():
        self.dataHandle = Data.rooms[key]
        validRoom = True
        # Valid room. Collect room data
        self.name = name.upper()
        self.connections = self.dataHandle["CONNECTIONS"]
        self.unvisitedDesc = self.dataHandle["UNVISITED_DESC"]
        self.visitedDesc = self.dataHandle["VISITED_DESC"]
        self.locked = locked
        # We'll populate rooms with items individually inside Game (for clarity)
        # Initialize each room with an empty inventory
        self.inventory = Inventory.RoomInventory([])
      
    if(validRoom == False):
      # INVALID ITEM! DO NOT INSTANTIATE!
      raise Exception("Attempt to instantiate an invalid room!")
      del self

  def name(self):
    return self.name
  
  def getConnections(self):
    out = ""
    for con in self.connections:
      if self.connections[-1] != con:
        out += con + ", "
      else:
        out += con + ". "
    return out
   
  def examine(self):
    ret = self.name + ": "    
    #Give the room description
    if(self.visited):
      ret += self.visitedDesc
    else:
      self.visited = True
      ret += self.unvisitedDesc
    #Describe the room's connections
    ret += " You can reach the following rooms from here: "
    ret += self.getConnections()
    return ret

  def lookAround(self):
    ret = ""
    #Describe the room's contents (inventory)
    if(self.name != "OUTSIDE"):
      ret += " Looking around, you see: "
      ret += Utils.Formatter.outputList(self.inventory.inventory) 
      Utils.Formatter.output(ret)
    else:
      Utils.Formatter.output("There's nothing to look for outside.")
  
  def hasItem(self, itemName):
    return self.inventory.hasItem(itemName)
    
  def addItems(self, items):
    self.inventory.addItems(items)
  
  def removeItems(self, itemNames):
    self.inventory.removeItems(itemNames) 
