import Data

class Item(object):
 
  name = None
  desc = None
 
  #Name must have (only) leading capitals
  #'RC Car' == WRONG
  #'Rc Car' == RIGHT
  def __init__(self,name):
  
    #Make sure that the item is valid (inside our game data's item list)
    validItem = False
    for key in Data.items:
      if key == name.upper():
        #VALID ITEM
        self.name = key
        self.desc = Data.items[key]["DESC"]
        validItem = True
    if(validItem == False):
      #INVALID ITEM! DO NOT INSTANTIATE!
      raise Exception("Attempt to instantiate an invalid item!")
      del self

  def examine(self):
    return(self.desc)

  def __str__(self):
    return self.name