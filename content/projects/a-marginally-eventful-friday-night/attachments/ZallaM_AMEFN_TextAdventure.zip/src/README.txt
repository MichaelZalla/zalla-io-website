Thank you for downloading "A Marginally Eventful Friday Night".

How to run this game:

1. Open Terminal (or some other shell environment) on your computer.
2. Navigate to this folder, using whatever native commands you are familiar with ('cd', etc).
3. Enter 'python __init.py__' to feed the main driver program to the Python interpreter.

If you experience errors running the game, you may not have the correct version of Python installed, or included in your $PATH. This text adventure was developed to work with the Python 2.7 interpreter, and has not been tested on other versions.
