import sys

from lib import Data
from lib import Inventory
from lib import Item
from lib import Room
from lib import Utils

#======  ======#

class Game(object):
  
  #====== INITIALIZATION ======#

  powerIsOut = False
  basementTriggered = False
  powerIsBackOn = False

  # Set a starting location  
  currentRoom = "OUTSIDE"
  
  # Holds a dictionary of Room objects, indexed by name (e.g. - rooms["KITCHEN"] = Kitchen instance)
  rooms = {} 
  
  # Instantiate some rooms
  rooms["OUTSIDE"] = Room.Room("OUTSIDE", True)         # Locked
  rooms["KITCHEN"] = Room.Room("KITCHEN", True)         # Locked
  rooms["LIVING ROOM"] = Room.Room("LIVING ROOM", True) # Locked
  rooms["BASEMENT"] = Room.Room("BASEMENT", True)       # Locked
  rooms["BEDROOM"] = Room.Room("BEDROOM", False)        # Unlocked
  rooms["BATHROOM"] = Room.Room("BATHROOM", True)       # Licked
  
  # Generate our game's rooms
  roomNames = []
  for room in rooms.keys():
    roomNames.append(room)
    
  #print roomNames
  
  # Populate our rooms with initially 'visible' items
  
  rooms["KITCHEN"].addItems([Item.Item("NOTE"),
                             Item.Item("PACKAGE")])
  
  rooms["BASEMENT"].addItems([Item.Item("BROKEN FUSE")])

  #====== CONSTRUCTOR ======#self
  def __init__(self):
    
    # Attach function references to our item data (these functions are at the bottom of Game)
    Data.items["HOUSE KEY"]["USE"] = self.useHouseKey
    Data.items["PACKAGE"]["USE"] = self.usePackage
    Data.items["SCISSORS"]["USE"] = self.useScissors
    Data.items["ADVENTURE SLEUTH GAME"]["USE"] = self.useAdventureSleuthGame
    Data.items["FUSE"]["USE"] = self.useFuse
    
    self.inventory = Inventory.PlayerInventory([])
    # Print introduction
    self.intro()
    # Wait for player to START
    while 1:
      command = raw_input('>> ').upper()
      if command.upper() == 'START':
        break
      if command.upper() == 'QUIT':
        # Quit the program
        sys.exit()
      else:
        Utils.Formatter.output("I don't understand that!")
    
    # Add the HOUSE KEY to our player's INVENTORY
    self.inventory.addItems([Item.Item("HOUSE KEY")])
    
    # Begin the game loop!
    self.loop()
    
  def loop(self):
    self.examineRoom()
    while True:
      self.interpretCommand(raw_input(">> ").rstrip('\n'))
      #If the player has a working FLASHLIGHT, unlock the basement
      #I really should be putting this code elsewhere, but this is easy
      if self.inventory.hasItem("FLASHLIGHT"):
        self.rooms["BASEMENT"].locked = False;
          
  #====== INTERPRET COMMAND ======#  
  def interpretCommand(self, command):
    
    Utils.Formatter.output("")
    command = command.upper()
    
    simpleCommands = { "QUIT": self.quit, "EXIT": self.quit,
                       "HELP": self.help,
                       "EXAMINE ROOM": self.examineRoom,
                       "LOOK AROUND": self.rooms[self.currentRoom].lookAround,
                       "INVENTORY": self.showInventory, "I": self.showInventory }
    
    # Check if it's just a SIMPLE command    
    for c in simpleCommands:
      if command == c:
        simpleCommands[c]()
        return
      
    # Otherwise, check if it's an ENTER [ROOM] or EXAMINE [ROOM] command    
    for roomName in self.roomNames: 
      if (command == "ENTER " + roomName) or (command == "GO TO " + roomName):
        # The logic of changing rooms (and whether it's even legal) is all handled by self.changeRoom()
        self.changeRoom(roomName)
        return
      # The player should only be able to examine their current room
      if (command == "EXAMINE " + roomName) or command == ("X " + roomName):
        if roomName == self.currentRoom:
          self.examineRoom()
          return
        else:
          Utils.Formatter.output("You cannot examine a room that you are not currently in!")
          return

    # Otherwise, check if it's a TAKE [ITEM], EXAMINE [ITEM], or USE [ITEM] command
    for itemName in Data.items:
      
      if command == "TAKE " + itemName or command == "PICK UP " + itemName:
        # The player should only be able to take items that exist in the current room   
        if self.rooms[self.currentRoom].hasItem(itemName):
          # Remove the item from the room
          self.rooms[self.currentRoom].removeItems([itemName])
          # Add the item to the player's inventory
          item = Item.Item(itemName)
          Utils.Formatter.output("You take the " + itemName + ", and add it to your inventory.")
          self.inventory.addItems([item])  # Remember that addItems() takes a LIST, not just an ITEM. So we wrap it in brackets!
          return
        else:
          Utils.Formatter.output("I don't understand that!")
          return
      
      if command == ("EXAMINE " + itemName) or command == ("X " + itemName):
        # The player should only be able to examine items currently in their inventory
        if self.inventory.hasItem(itemName) or self.rooms[self.currentRoom].hasItem(itemName):
          # We'll just statically access the description from Data (no need to access it from a specific inventory)
          Utils.Formatter.output(Data.items[itemName]["DESC"])
          return
        else:
          Utils.Formatter.output("You cannot EXAMINE an item that is not in the room or in your inventory!")
          return
      
      if command == "USE " + itemName:
        # The player should only be able to use items currently in their inventory
        if self.inventory.hasItem(itemName):
          # Not every item may have a USE function, so first check that it exists/is defined
          if "USE" in Data.items[itemName]:
            # The conditional logic for using an item is encapsulated inside its USE function
            Data.items[itemName]["USE"]()
            return
          else:
            # No USE function is defined
            Utils.Formatter.output("You can't USE this item!")
            return
        else:
          Utils.Formatter.output("You cannot USE an item that is not currently in your inventory!")
          return
    
      if command == "OPEN PACKAGE":
        #The player should only be able to use the item if it is in their inventory
        if self.inventory.hasItem("PACKAGE"):
          Data.items["PACKAGE"]["USE"]()
          return
        
    # Otherwise, check if it's a USE WITH command ("USE " + ITEM + " WITH " + ITEM)
    if (command.split(" ")[0] == "USE") and (command.split(" ").index("WITH") != -1):
      words = command.split(" ") # [USE],[ITEM 1],[WITH],[ITEM 2]
      #We can parse out items of arbitrary word length ("BALL" vs. "HEAVY BALL"), and our interpreter should still work
      start, end = words.index("USE") + 1, words.index("WITH")
      item1 = words[start:end]
      start, end = words.index("WITH") + 1, len(words)
      item2 = words[start:end]
      #Strip out any brackets, quotations and commas for 'clean' item names
      item1 = str(item1).replace("[","").replace("]","").replace("'","").replace(",","")
      item2 = str(item2).replace("[","").replace("]","").replace("'","").replace(",","")
      #Call Inventory.combineItems(), passing it the requested pair of items      
      self.inventory.combineItems(item1, item2)
      return
    
    # Otherwise, it must not be a valid command        
    Utils.Formatter.output("I don't understand that command! (For a list of valid commands, type HELP)")
    return
  
  #====== CHANGE ROOMS ======#
  def changeRoom(self, roomName):
    #If the player requests to move into their current room, give them a message
    # letting them know they're already there
    if roomName == self.currentRoom:
      Utils.Formatter.output("You're already in the " + roomName.lower() + "!")
      return
    # Otherwise, check that it's a valid room to move to
    validMoves = self.rooms[self.currentRoom].connections
    for move in validMoves:
      if roomName == move:
        if(self.rooms[roomName].locked == False):
          # Is a valid move
          # Update currentRoom, and print out the new room description
          self.currentRoom = roomName
          self.examineRoom()      
          return    
        else:
          # The target room is locked! Let the player know why ...
          Utils.Formatter.output(Data.rooms[roomName]["LOCKED_MSG"])
          #SPECIAL EVENT FOR BASEMENT 
          if roomName == "BASEMENT" and self.powerIsOut and self.basementTriggered == False:
            self.tryBasement()
            self.basementTriggered = True #Don't want to repeatedly add items to the rooms!
          return
    # Is not a valid move
    Utils.Formatter.output("That is not an adjacent room!")
    return

  #====== EXAMINE ROOMS ======#
  def examineRoom(self):
    Utils.Formatter.output("")
    Utils.Formatter.output("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    Utils.Formatter.output(self.rooms[self.currentRoom].examine())
    
  def intro(self):  #====== INTRO ======#  
    Utils.Formatter.output("")
    Utils.Formatter.output("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    Utils.Formatter.output("Welcome to A Marginally Eventful Friday Night, a relatively lame text-based (adventure?) game where you play as NICK, "
                           "who has just arrived home from school. The aim of this puzzle-game is to (finally) get to play your game (more on this "
                           "later). Some text-based adventure games are well-written, innovative puzzles that may combine clever dialogue, intuitive "
                           "commands and a bug-free code base. With A Marginally Eventful Friday Night, none of these seem to be the case.")
    Utils.Formatter.output("However, you can interact with several ROOMS and ITEMS using commands like ENTER, TAKE, and USE. For a detailed "
                           "list of commands and command syntax, type HELP into the console.")
    Utils.Formatter.output("To begin the game, type START and press RETURN. ")
    Utils.Formatter.output("To cancel this program, type QUIT and press RETURN.")
    
   
  def help(self):  #====== HELP ======# 
    Utils.Formatter.output("")
    Utils.Formatter.output("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    Utils.Formatter.output("HELP MENU:")
    Utils.Formatter.output("Welcome to the HELP MENU. The following are valid commands for interacting with the game world. Note that all "
                           "command should be entered in ALL CAPS. Words within the game's narrative and descriptions that are in ALL CAPS are "
                           "probably important, and may be giving you a clue: ")
    Utils.Formatter.output("ROOMS:")
    Utils.Formatter.output("When you enter a ROOM, you will be given a description of the room that may include a list of those ROOMS that are "
                           "connected to the current room. This description may change as you progress through the game. If you ever wish to see "
                           "the current room's description again, you can EXAMINE it by typing EXAMINE [ROOM] (e.g. - 'EXAMINE KITCHEN'), or simply "
                           "X [ROOM] (e.g. - 'X KITCHEN'). When entering a room (and not only for the first time), it is very important to LOOK AROUND, as "
                           "doing so will make obvious the ITEMS that exist inside the ROOM. You can move between rooms by typing ENTER [ROOM] "
                           "(e.g. - 'ENTER LIVING ROOM') or typing GO TO [ROOM] (e.g. - 'GO TO KITCHEN'). The ROOM you specify must be connected "
                           "to your current room. ")
    Utils.Formatter.output("ITEMS:")
    Utils.Formatter.output("You may find an ITEM or ITEMS inside a ROOM. ITEMS inside a ROOM will be revealed when you use the EXAMINE [ROOM] "
                           "command. To place these ITEMS in your INVENTORY, type TAKE [ITEM] (e.g. - 'TAKE BALL'). You could also type 'PICK UP "
                           "[ITEM]'. You will receive a message saying that the item has been successfully added to your INVENTORY. You can view "
                           "your INVENTORY at any time using the INVENTORY command. Sometimes you may want to USE an ITEM for a specific purpose. "
                           "In the correct situation, you can use the USE [ITEM] (e.g. - 'USE BALL') command to use the item. Some items can be "
                           "combined with other items to form a new ITEM. You can do this using the USE [A] WITH [B] (e.g. - 'USE PENCIL WITH PAPER') "
                           "command.")
    Utils.Formatter.output("You can view this HELP MENU at any point in the game by typing HELP.")
  
    
  def quit(self):  #====== QUIT ======#  
    Utils.Formatter.output("Are you sure you want to quit?")
    userInput = raw_input("Y/N: ").upper()
    print ""
    if userInput == 'Y':
      sys.exit()
    elif userInput != 'N':
      print "Input is invalid. Enter a 'Y' or an 'N'!"
      self.quit()

  def showInventory(self):
    self.inventory.display()
    
  #====== Special Item Functions ======#
  
  #Trigger some actions when the power goes out ...
  def powerOutage(self):
    if self.powerIsOut == False:
      self.powerIsOut = True
      #Update the basement's 'locked' message
      Data.rooms["BASEMENT"]["LOCKED_MSG"] = Data.rooms["BASEMENT"]["LOCKED_MSG_2"]
      
  
  def tryBasement(self):
    # The following items will be added to the game after the player tries to enter the basement
    # for the first time following the power outage
    self.rooms["BEDROOM"].addItems([Item.Item("EMPTY FLASHLIGHT")])
    self.rooms["KITCHEN"].locked = False
    self.rooms["KITCHEN"].addItems([Item.Item("FUSE")])  
    self.rooms["LIVING ROOM"].locked = False
    self.rooms["LIVING ROOM"].addItems([Item.Item("BATTERY")])
    self.rooms["BATHROOM"].locked = False
    self.rooms["BATHROOM"].addItems([Item.Item("BATTERY")])
  
  def useHouseKey(self):
    if self.currentRoom == "OUTSIDE":
      Utils.Formatter.output("You insert the HOUSE KEY into the front door. As you turn it, you hear the familiar 'CLICK' of the sliding dead bolt.")
      Utils.Formatter.output("You swing open the door and enter into the KITCHEN.")
      # Unlock Kitchen
      self.rooms["KITCHEN"].locked = False
      # Move to Kitchen
      self.changeRoom("KITCHEN")
      # Update HOUSE KEY description
      Data.items["HOUSE KEY"]["DESC"] = "A small metal house key. Amazingly, it didn't vanish from your inventory after unlocking the door. How unconventional!"
    else:
      Utils.Formatter.output("You can't use that item here!")

  #Conditional logic for opening the PACKAGE. May cause a SCISSORS to spawn in the KITCHEN
  def usePackage(self):
    if self.currentRoom == "BEDROOM":
      if self.inventory.hasItem("SCISSORS"):
        Utils.Formatter.output("Maybe try to USE the SCISSORS to open the PACKAGE.")
      else:
        if self.rooms["KITCHEN"].hasItem("SCISSORS") == False:
          #The SCISSORS have not been spawned yet. Better add them.
          self.rooms["KITCHEN"].addItems([Item.Item("SCISSORS")])
        Utils.Formatter.output("The package appears to be covered in tape. You Dad loves to pull this kind of nonsense on you. Try looking around the house "
                                 "for something you could use to open it.") 
    else:
      Utils.Formatter.output("You should really be opening this in your room!")
      
  def useScissors(self):
    if self.currentRoom == "BEDROOM":
      if self.inventory.hasItem("SCISSORS"):
        Utils.Formatter.output("You take the scissors and clumsily liberate the package from its contents (or vice-versa?). Throwing the lacerated "
                               "packaging across the room, you turn your gaze back to the exposed box and see ... Could it be? In your hands is a "
                               "brand new copy of 'Adventure Sleuth 2: The Great Lamasery Incident.' You don't seem to remember asking your parents "
                               "for this, but that curiosity will have to wait." )
        #Add the game to the player's inventory
        self.inventory.addItems([Item.Item("ADVENTURE SLEUTH GAME")])
        Utils.Formatter.output("The black plastic power switch gives off an audible 'CLICK' as you turn on your trusty Commodore 64. Within seconds, "
                               "you are greeted with a blinking blue start screen:" )
        Utils.Formatter.output("    **** COMMODORE 64 BASIC V2 ****\n"
                               "64K RAM SYSTEM   38911 BASIC BYTES FREE\n"
                               "READY.")
                               
        Utils.Formatter.output("What are you standing around for? If you want to play the game, you'd better USE it!")

  #This is where the POWER OUTAGE gets triggered!
  def useAdventureSleuthGame(self):
    if self.currentRoom == "BEDROOM":
      
      if self.powerIsBackOn == False:
        Utils.Formatter.output("Taking no time to admire the colorful label, you shove the small game disc into your computer's floppy drive and connect "
                               "the drive to the motherboard's serial port. As the drive purrs to life, you enter in a remarkably accurate console command: " )
        Utils.Formatter.output("LOAD ':*',8,1")
        Utils.Formatter.output("For a brief second, your screen is filled with splashes of bright, blocky color. Suddenly, without warning, a huge flash of "
                               "light fills your room from the window, followed by a loud 'CRRAAACCCKKKKKK!!!' You watch as your 1084 monitor powers off, "
                               "leaving you alone with a black rectangular abyss. By now, you've made the assumption that the electric discharge from a "
                               "nearby lightning strike has set off the circuit breaker in your house." )
        Utils.Formatter.output("In a last ditch effort to avoid a night of utter boredom, you remove the game from your now-dormant Commodore and set off "
                               "to restore power by any means necessary. You should probably start by investigating the BASEMENT.")
        self.powerOutage()
    
      else:
        #Time to end the game!
        Utils.Formatter.output("You place the game disc back into the floppy drive. Running a quick command into the Commodore's start screen, "
                               "you are greeted with an exciting start screen for 'Adventure Sleuth 2: The Great Lamasery Incident'. At last! \n "
                               "(Coincidentally, you have also just won the game! Not that you knew this was a game. But congratulations, regardless! "
                               "You can quit the game by typing 'QUIT' into console.")
    
    else:
      Utils.Formatter.output("You can't use that item here!")
  
  def useFuse(self):
    if self.currentRoom == "BASEMENT":
      if self.rooms["BASEMENT"].hasItem("BROKEN FUSE") == False:
        Utils.Formatter.output("Going against all parental wisdom you've received during your brief lifetime, you take the new FUSE and carefully push it "
                               "into place inside the fuse box. Immediately, the light returns to the room, and you hear the faint hum of the air conditioning "
                               "coming back online. You're certain that, were you to return to your BEDROOM, your Commodore would be back online, too!")
        Data.rooms["BEDROOM"]["VISITED_DESC"] = ("You're back in your bedroom. Looks like your Commodore is powered back on! Better USE your ADVENTURE SLEUTH "
                                                 "DISC, and you'll be in the game in no time!")
        self.powerIsBackOn = True
      else:
        Utils.Formatter.output("You need to TAKE the BROKEN FUSE from the fuse box first!")
        
    else:
      Utils.Formatter.output("You can't use that item here!")
    
